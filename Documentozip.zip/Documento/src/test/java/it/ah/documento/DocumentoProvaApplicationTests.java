package it.ah.documento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentoProvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
