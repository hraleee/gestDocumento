function azione(){
	
	console.log("ciao")
	
	window.location = '/ricercaD'
	
	
}