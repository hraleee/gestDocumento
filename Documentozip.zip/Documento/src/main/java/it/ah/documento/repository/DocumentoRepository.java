package it.ah.documento.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.ah.documento.model.Documento;

public interface DocumentoRepository extends JpaRepository<Documento,Integer>{

	
}
