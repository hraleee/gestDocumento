package it.ah.documento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentoProvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentoProvaApplication.class, args);
	}

}
