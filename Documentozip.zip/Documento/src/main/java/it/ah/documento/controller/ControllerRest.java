
package it.ah.documento.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.ah.documento.model.Documento;
import it.ah.documento.service.DocumentoService;



@RestController
public class ControllerRest {

	@Autowired
	private DocumentoService Ds;
	
	
	@PostMapping("inserisciDocumento")
	public String vaiInserisciDoc(@ModelAttribute Documento d) {
		
		boolean esito= this.Ds.SalvaDocumento(d);
		
		if(esito==true) {
			
			return "Inserimento andato a buon fine";
		}
		else
		{
			return "Inserimento fallito";
		}
		
		
		
	}
	
	
	
	
	@GetMapping("ricerca")
	public Optional<Documento> viaTrovaDocumento(@RequestParam Integer id){
		
		
		Optional<Documento> d  = this.Ds.trovaDocumento(id);
		
		
		return d;
		
		
	}
	
	
	
	
	
	@GetMapping("CancellaDocumento")
	@DeleteMapping("CancellaDocumento")
	public String cancella(@RequestParam Integer id) {
		
		Optional <Documento> c= this.Ds.trovaId(id);
		
		boolean trovato = this.Ds.cancellaDocumento(c);
		
		if(trovato==true) {
			return "Eliminazione avvenuta con successo";
		}
		else {
			return "Utente non trovato";
		}
		
	}
	
	
	
	@PutMapping("ModificaDocumento")
	public ResponseEntity<Documento> vaiModifica(@RequestParam Integer id, @RequestBody Documento d) {
		
		Documento da= this.Ds.trovaIdDocum(id);
		
		da.setTipologiaDocumento(d.getTitolo());
		
		da.setDataCreazione(d.getDataCreazione());
		
		da.setTipologiaDocumento(d.getTipologiaDocumento());
	
		Documento dd = this.Ds.SalvaDocumentoD(da);
		
		
		
		return new ResponseEntity<>(dd,HttpStatus.CREATED);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
