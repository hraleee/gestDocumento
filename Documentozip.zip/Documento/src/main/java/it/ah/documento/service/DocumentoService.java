package it.ah.documento.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.ah.documento.model.Documento;
import it.ah.documento.repository.DocumentoRepository;

@Service
public class DocumentoService {

	@Autowired
	private DocumentoRepository dS;
	
	
	
	public boolean SalvaDocumento(Documento d) {
		
		
		
		
		if(d!=null) {
			this.dS.save(d);
			return true;
		}
		else {
			return false;
		}
		
		
		
		
	}
	
	
	
	public Optional<Documento> trovaDocumento(Integer id){
		
		
		return this.dS.findById(id);
		
	}
	
	
	
	public Optional<Documento> trovaId(Integer id) {
		
		return this.dS.findById(id);
		
		
		
	}
	
	
    public Documento trovaIdDocum(Integer id) {
		
    	Optional<Documento> dd= this.dS.findById(id);
    	
    	if(dd.isPresent()) {
    		
    		return dd.get();
    	}
    	else
    	{
    		return null;
    	}
		
				
		
		
		
	}
	
	
	
	public boolean cancellaDocumento(Optional<Documento> d) {
		
		boolean trovato=false;
		
		if(d.isPresent()) {
		
		 this.dS.delete(d.get());
		 return trovato=true;
		}
		else {
			
			return trovato;
		}
		
		
		
	}
	
public Documento SalvaDocumentoD(Documento d) {
		
		
		
		
		if(d!=null) {
			
			return this.dS.save(d);
			
		}
		else {
			return d;
		}
		
}
	
	
	
}
