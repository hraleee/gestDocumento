package it.ah.documento.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerGenerale {

	
	@GetMapping("home")
	public String vaiHome() {
		return "home";
	}
	
	
	@GetMapping("ricercaD")
	public String vaiRicerca() {
		
		return "ricercaD";
	}
	
	
	@GetMapping("inserisci")
	public String vaiInserimento() {
		
		return "inserisci";
	}
	
	
	
	
}
